export const users = [
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    },
    {
        name: 'Kunal Tyagi',
        url: 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg'
    }
];

export const drawers = [
    "Existing Inventory",
    "Used Inventory",
    "Trade-In",
    "Test Drive",
    "Cybertruck",
    "Roadster",
    "Semi",
    "Charging",
    "Powerwall",
    "Commercial Energy",
    "Utilities",
    "Find Us",
    "Support",
    "Investor Relations"
]